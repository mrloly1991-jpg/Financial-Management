---
name: xampp-backend-integration
description: Skill khusus untuk perancangan database MySQL/MariaDB di phpMyAdmin dan pembuatan backend PHP pada lingkungan lokal XAMPP.
---

# Skill 4: Integrasi Backend PHP & Database MySQL (Lingkungan XAMPP)

## Peran & Fokus Utama
Menangani arsitektur penyimpanan data permanen pada **Tahap 2** menggunakan lingkungan server lokal **XAMPP** (Apache + MySQL/MariaDB + PHP).

## Konfigurasi Lingkungan XAMPP
- **Lokasi Folder Proyek**: `C:/xampp/htdocs/financial-management/`
- **Akses Web Lokal**: `http://localhost/financial-management/`
- **Akses Database**: `http://localhost/phpmyadmin/`
- **Kredensial Koneksi Default XAMPP**:
  - Host: `localhost` (Port `3306`)
  - User: `root`
  - Password: `""` (kosong)
  - Database Name: `db_financial_management`

## Skema Tabel Database (MySQL / MariaDB)
1. **`transactions`**:
   - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
   - `transaction_date` (DATE)
   - `type` (ENUM: `'income'`, `'expense'`)
   - `category_rule` (ENUM: `'needs'`, `'wants'`, `'savings'`)
   - `title` (VARCHAR 150)
   - `amount` (DECIMAL 15,2)
   - `created_at` (TIMESTAMP)

2. **`saving_goals`**:
   - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
   - `item_name` (VARCHAR 150)
   - `target_amount` (DECIMAL 15,2)
   - `current_amount` (DECIMAL 15,2, DEFAULT 0)
   - `start_date` (DATE)
   - `target_date` (DATE)
   - `status` (ENUM: `'active'`, `'completed'`)

3. **`saving_logs`**:
   - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
   - `goal_id` (INT, FOREIGN KEY ke `saving_goals.id`)
   - `deposit_date` (DATE)
   - `amount` (DECIMAL 15,2)

4. **`education_progress`**:
   - `id` (INT, AUTO_INCREMENT, PRIMARY KEY)
   - `module_slug` (VARCHAR 100)
   - `quiz_score` (INT)
   - `completed_at` (TIMESTAMP)

## Aturan Transisi Tahap 1 ke Tahap 2
- Pada **Tahap 1**, gunakan objek layanan data (`DataService`) berbasis `localStorage` agar antarmuka langsung berfungsi tanpa database.
- Pada **Tahap 2**, ganti fungsi di dalam `DataService` dengan `fetch()` ke *endpoint* PHP (`api/koneksi.php`, `api/transactions.php`, `api/goals.php`, `api/education.php`) menggunakan PDO agar aman dari SQL Injection, serta sediakan file `database.sql` siap *import* ke phpMyAdmin di XAMPP.
